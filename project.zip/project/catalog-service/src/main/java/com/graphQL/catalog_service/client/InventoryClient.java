package com.graphQL.catalog_service.client;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.client.HttpGraphQlClient;
import org.springframework.stereotype.Component;

import com.graphQL.catalog_service.dto.IteamDto;
import com.graphQL.catalog_service.dto.IteamRequestDto;

@Component
public class InventoryClient {
	
	@Autowired
	private HttpGraphQlClient graphQlClient;
	
	public List<IteamDto> viewProducts(){
		String graphQLQuery="query GetProducts {\r\n"
				+ "    getProducts {\r\n"
				+ "        name\r\n"
				+ "        price\r\n"
				+ "    }\r\n"
				+ "}";
		
		//path--endpoint getProducts
		return graphQlClient.document(graphQLQuery)
				.retrieve("getProducts").toEntityList(IteamDto.class).block(); 
		//category,stock nhai hai to null dega therefore we are using jsoninclude non_defalt dto side
	}
	
	
	public List<IteamDto> viewProductsByCategory(String category){
		
		String graphQLQuery=String.format("query GetProducts {\r\n"
				+ "    getProductsByCategory(category: \"%s\") {\r\n"
				+ "        name\r\n"
				+ "        category\r\n"
				+ "        price\r\n"
				+ "        stock\r\n"
				+ "    }\r\n"
				+ "}\n",category);
		
		return graphQlClient.document(graphQLQuery)
				.retrieve("getProductsByCategory").toEntityList(IteamDto.class).block();
	}
	
	public IteamDto receiveNewShipment(IteamRequestDto itemRequestDto) {
		String graphQLQuery=String.format("mutation ReceiveNewShipment {\r\n"
				+ "    receiveNewShipment(id: \"%s\", quantity: %d) {\r\n"
				+ "        name\r\n"
				+ "        price\r\n"
				+ "        stock\r\n"
				+ "    }\r\n"
				+ "}\n", itemRequestDto.getId(),itemRequestDto.getQuantity());
		
		return graphQlClient.document(graphQLQuery)
				.retrieve("receiveNewShipment").toEntity(IteamDto.class).block();
	}
	
}
