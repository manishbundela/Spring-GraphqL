package com.graphQL.catalog_service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.graphQL.catalog_service.dto.IteamDto;
import com.graphQL.catalog_service.dto.IteamRequestDto;
import com.graphQL.catalog_service.service.CatalogService;

@RestController
@RequestMapping("/Catalog")
public class CatalogController {

	@Autowired
	private CatalogService catalogService;
	
	@GetMapping("/products")
	public List<IteamDto> viewProducts(){
		return catalogService.viewProducts();
	}
	@GetMapping("/products/catagory")
	public List<IteamDto> viewProductsByCategory(String category){
		return catalogService.viewProductsByCategory(category);
	}
	
	@GetMapping("/shipment")
	public IteamDto receiveNewShipment(IteamRequestDto itemRequestDto) {
		return catalogService.receiveNewShipment(itemRequestDto);
	}
}
