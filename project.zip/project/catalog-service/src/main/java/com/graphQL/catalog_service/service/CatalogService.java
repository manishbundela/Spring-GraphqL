package com.graphQL.catalog_service.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.graphQL.catalog_service.client.InventoryClient;
import com.graphQL.catalog_service.dto.IteamDto;
import com.graphQL.catalog_service.dto.IteamRequestDto;

@Service
public class CatalogService {

	@Autowired
	private InventoryClient inventoryClient;
	
	public List<IteamDto> viewProducts(){
		return inventoryClient.viewProducts();
	}
	
	public List<IteamDto> viewProductsByCategory(String category){
		return inventoryClient.viewProductsByCategory(category);
	}
	public IteamDto receiveNewShipment(IteamRequestDto itemRequestDto) {
		return inventoryClient.receiveNewShipment(itemRequestDto);
	}
	
}
