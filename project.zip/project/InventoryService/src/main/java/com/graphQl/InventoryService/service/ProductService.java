package com.graphQl.InventoryService.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.graphQl.InventoryService.entity.Product;
import com.graphQl.InventoryService.repositry.ProductRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ProductService {

	@Autowired
	private ProductRepository repository;
	
	public List<Product> getProducts(){
		return repository.findAll();
	}
	
	public List<Product> getProductsByCategory(String category){
		return repository.findByCategory(category);
	}

	public Product updateProduct(int id,int stock){
		System.out.println(id+ ":: "+stock);
		Product existing=repository.findById(id).orElseThrow(()->new RuntimeException("product not found with id "+id));
		
		System.out.println(" :::::::::::: "+existing.getStock());
		existing.setStock(stock);
		return repository.save(existing);
	}
	
	public Product receiveNewShipment(int id,int quantity){
		Product existing=repository.findById(id).orElseThrow(()->new RuntimeException("product not found with id "+id));
		
		existing.setStock(existing.getStock()+quantity);
		return repository.save(existing);
	}

	public Product delectProduct(int id) {
		Product existing=repository.findById(id).orElseThrow(()->new RuntimeException("product not found with id "+id));
		if(existing!=null) {
			repository.delete(existing);
		}
		
		return existing;
	}
}
