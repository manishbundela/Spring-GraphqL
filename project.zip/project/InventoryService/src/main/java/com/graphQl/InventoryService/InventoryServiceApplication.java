package com.graphQl.InventoryService;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.graphQl.InventoryService.entity.Product;
import com.graphQl.InventoryService.repositry.ProductRepository;

import jakarta.annotation.PostConstruct;

@SpringBootApplication
public class InventoryServiceApplication {

	/*
	 * @Autowired private ProductRepository repository;
	 * 
	 * @PostConstruct public void initDB() { used for insert record in DB.
	 * List<Product> products=Stream.of( new Product( "Laptop", "ELectronics",
	 * "7999.99f", 50), new Product("SmartPhone", "ELectronics", "3999.99f", 250),
	 * new Product("Office chair", "Furniture", "2999.99f", 530), new Product(
	 * "NotBook", "Stationery", "1999.99f", 150), new Product( "Desk Lamp",
	 * "Furniture", "799.99f", 450), new Product( "Water Bottle", "Accessories",
	 * "8999.99f", 90), new Product( "Mobile", "ELectronics", "499.99f", 950)
	 * ).collect(Collectors.toList());
	 * 
	 * repository.saveAll(products); }
	 */

	public static void main(String[] args) {
		SpringApplication.run(InventoryServiceApplication.class, args);
	}

}
