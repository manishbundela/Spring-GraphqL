package com.graphQl.InventoryService.resource;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import com.graphQl.InventoryService.entity.Product;
import com.graphQl.InventoryService.service.ProductService;


@Controller
public class ProductGraphQLController {


	@Autowired
	private ProductService service;
	
	@QueryMapping
	public List<Product> getProducts(){
		return service.getProducts();
	}
	
	@QueryMapping
	public List<Product> getProductsByCategory(@Argument String category){
		return service.getProductsByCategory(category);
	}
	
	@MutationMapping
	public Product updateProduct(@Argument int id,@Argument int stock){
		return service.updateProduct(id, stock);
	}
	
	@MutationMapping
	public Product receiveNewShipment(@Argument int id,@Argument int quantity){
		return service.receiveNewShipment(id, quantity);
	}
	
	@MutationMapping
	public Product delectProduct(@Argument int id) {
		return service.delectProduct(id); 
	} 
	
}


